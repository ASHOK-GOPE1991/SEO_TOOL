from urllib.request import urlopen
from bs4 import BeautifulSoup
import re
url=input("Which page would you like to check? Enter Full URL: ");
keyword-input("What is your SEO Keyword?")
keyword=keyword.casefold()
try:
    html=urlopen(url)
except HTTPError as e:
    print(e)
data=BeautifulSoup(html,"html.parser")
def seo_title_found(keyword,data):
    if data.title:
        if keyword in data.title.text.casefold():
            status="Found"
        else:
            status="keyword Not Found"
    else:
        status="Not title found"
    return status
def seo_title_stop_words(data):
    words=0
    list_words= []
    if data.title:
        with open('stopwords.txt','r') as f:
            for line in f:
                if re.search(r'\b'+line.rstrip('\n') +r'\b',data.title.text.casefold()):
                    words+=1
                    list_words.append(line.rstrip('\n'))
        if words > 0:
            stop_words="We found {} stop words in your title. You should consider removing them {}".format(words,list_words)
        else:
            stop_words="we found no stop words in the Title. Good Work!"
            
    else:
        stop_words="We could not find a title"
    return stop_words
def seo_title_length(data):
    if data.title:
        if len(data.title.text) < 60:
            length="Your length is under the maximum suggested length of 60 characters. Your title is {}".format(len(data.title.text))
        else:
            length="Your length is over the maximum suggest length of 60 character. Your title is {}".format(len(data.title.text))
    else:
        length="No title was found "
    return length
            
        
                                                                                                                 
print(seo_title_found(keyword,data))
print(seo_title_stop_words(data))
print(seo_title_length(data))
